﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace Assignment3Template
{
    // You are probably better to use the Circular array you made in the lab
    class CircularArray<T>
    {
        T[] thisarray;
        private int front = 0; // index of front element
        private int back = 0; // index of back element
        public CircularArray() // constructor
        { thisarray = new T[20]; }

        public CircularArray(int size) // constructor with a size
        { thisarray = new T[size]; }
        public void enqueue(T input, int inputPriority)
        {
            // adds an element based on priority.
            // Items with equal priority should be FIFO, but higher priorty should come first (so priority 5 jumps ahead of priority 4)

        }
        
        public T dequeue()
        {
            T temp = thisarray[front]; // 

            return temp;
            
        }
        public void printAll()
        {
            foreach (T x in thisarray)
            Console.WriteLine(x.ToString());
        }
        public void deleteAll()
        {
            // dequeue all elements.
        }

    }
}
