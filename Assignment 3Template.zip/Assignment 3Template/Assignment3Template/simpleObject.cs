﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment3Template
{
    class SO
    {
        public int key;

        // copy code from lab 5 (with modifications) here to make this into the assignment specification
        public SO(int inputkey)
        {
            key = inputkey;
        }
        
    }
}
